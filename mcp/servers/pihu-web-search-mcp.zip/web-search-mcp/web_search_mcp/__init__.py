"""PIHU Web Search MCP."""
